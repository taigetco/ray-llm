import logging

serve_logger = logging.getLogger("ray.serve")
aviary_logger = logging.getLogger("ray.aviary")
