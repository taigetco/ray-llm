# These constants may be overwritten at configuration time.
enable_returning_internal_exceptions = True
